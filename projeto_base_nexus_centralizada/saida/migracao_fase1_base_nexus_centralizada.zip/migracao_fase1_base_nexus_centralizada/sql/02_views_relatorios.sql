/* =====================================================================
   BASE NEXUS CENTRALIZADA — FASE 1: VIEWS DOS RELATÓRIOS
   ---------------------------------------------------------------------
   Mesmas colunas, mesmos nomes e mesmos valores das views atuais.
   No Power BI basta trocar a fonte:
     POWERBI_SUPORTE_B2C_NEXUS  ->  VW_NEXUS_SUPORTE_B2C
     POWERBI_DEPENDENCIA_NEXUS  ->  VW_NEXUS_DEPENDENCIA_CAMPO
   Nenhuma regra aqui: só leitura da MV_NEXUS_SUPORTE_CENTRAL.
   ===================================================================== */


/* ---------------------------------------------------------------------
   SUPORTE B2C (interno) — igual à POWERBI_SUPORTE_B2C_NEXUS
   ------------------------------------------------------------------- */
CREATE OR REPLACE VIEW VW_NEXUS_SUPORTE_B2C AS
SELECT
    C.ID_TABULACAO,
    C.MATRICULA_OPERADOR,
    C.DATA_INICIO,
    C.DATA_FIM,
    C.CHAMADO,
    C.TIPO_TROCA,
    C.ID_GPS,
    C.ATIVIDADE,
    C.ID_CADASTRO,
    C.PON,
    C.OLT,
    C.REDE,
    C.CRM,
    C.SLID,
    C.SLOT,
    C.PORTA,
    C.CABO,
    C.PRIMARIA,
    C.BANDA_DESIGNADOR,
    C.BANDA_IP_FIXO,
    C.TV_DESIGNADOR,
    C.TV_PACOTE,
    C.VOZ_DESIGNADOR,
    C.SPLITTER,
    C.AREA_TELEFONICA,
    C.CNL,
    C.DESIGNADOR_ACESSO,
    C.INSTANCIAS,
    C.AREA_GEOGRAFICA,
    C.AREA_BLACKOUT,
    C.TV_DISPOSITIVOS,
    C.ID,
    C.CLIENTE_ANATEL,
    C.STATUS_MAX,
    C.PRODUTO,
    C.DEFEITO,
    C.PROBLEMA,
    C.SOLUCAO,
    C.TIPO,
    C.RESOLUCAO,
    C.CO,
    C.COLABORADOR,
    C.SUPERIOR_IMEDIATO,
    C.COORDENACAO,
    C.GERENCIA,
    C.AREA_ATUACAO,
    C.TIPO_DE_CARGO,
    C.TIPO_OPERACAO,
    C.EMAIL,
    C.REGIONAL,
    C.CLUSTER_,
    C.UF_,
    C.CIDADE,
    C.LOCALIDADE_DETAIL,
    C.AT_NOME,
    C.API,
    C.FUNCIONALIDADE,
    C.DT_INICIO_MAGIC,
    C.USO_API_CORRETA,
    C.TIPO_DEPENDENCIA,
    C.CATEGORIA,
    C.CATEGORIA_DETALHE,
    C.REGRA_NEGOCIO_DEPENDENCIA
FROM MV_NEXUS_SUPORTE_CENTRAL C;


/* ---------------------------------------------------------------------
   DEPENDÊNCIA DE CAMPO (externo) — igual à POWERBI_DEPENDENCIA_NEXUS
   Sem nenhum dado de quem atendeu.
   SEQ_LINHA = 1: uma linha por tabulação, como na view atual.
   ------------------------------------------------------------------- */
CREATE OR REPLACE VIEW VW_NEXUS_DEPENDENCIA_CAMPO AS
SELECT
    C.ATIVIDADE,
    C.ID_TABULACAO,
    C.DATA_INICIO,
    C.DATA_FIM,
    C.DEP_DT_INICIO_MAGIC       AS DT_INICIO_MAGIC,
    C.PRODUTO_ORIGINAL          AS PRODUTO,
    C.DEFEITO,
    C.PROBLEMA,
    C.SOLUCAO,
    C.DEP_API                   AS API,
    C.DEP_FUNCIONALIDADE        AS FUNCIONALIDADE,
    C.DEP_FUNCIONALIDADE_MAGIC  AS FUNCIONALIDADE_MAGIC,
    C.CRM,
    C.TIPO_OS,
    C.DEP_MATRICULA             AS MATRICULA,
    C.DEP_TECNICO               AS TECNICO,
    C.DEP_CONTRATO              AS CONTRATO,
    C.DEP_CNL                   AS CNL,
    C.DEP_AT                    AS AT_,
    C.DEP_REGIONAL              AS REGIONAL,
    C.DEP_CLUSTER               AS CLUSTER_,
    C.DEP_REGIONAL_ACRONIMO     AS REGIONAL_ACRONIMO,
    C.DEP_UF                    AS UF_,
    C.DEP_ESTADO                AS ESTADO,
    C.DEP_CIDADE                AS CIDADE,
    C.DEP_CLUSTER_LATITUDE      AS CLUSTER_LATITUDE,
    C.DEP_CLUSTER_LONGITUDE     AS CLUSTER_LONGITUDE,
    C.DEP_TIPO                  AS TIPO,
    C.DEP_CATEGORIA             AS CATEGORIA,
    C.DEP_CATEGORIA_DETALHE     AS CATEGORIA_DETALHE
FROM MV_NEXUS_SUPORTE_CENTRAL C
WHERE C.FLAG_DEPENDENCIA = 1
  AND C.SEQ_LINHA = 1;
