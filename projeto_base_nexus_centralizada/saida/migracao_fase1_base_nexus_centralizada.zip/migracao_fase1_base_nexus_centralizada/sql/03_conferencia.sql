/* =====================================================================
   BASE NEXUS CENTRALIZADA — FASE 1: CONFERÊNCIA NO ORACLE
   ---------------------------------------------------------------------
   Compara as views atuais (produção) com as views novas.
   Somente consultas. Resultado esperado: ZERO diferenças.

   Como rodar:
   1. Atualize a base e, logo em seguida, rode as consultas:
        EXEC DBMS_MVIEW.REFRESH('MV_NEXUS_SUPORTE_CENTRAL', 'C', atomic_refresh => TRUE);
   2. As comparações usam do 1º dia do mês de 5 meses atrás até ONTEM:
      - "até ontem": o log do Magic é em tempo real, então o dia de hoje
        pode mudar entre a atualização da base e a consulta;
      - "5 meses": evita a borda da janela de 6 meses, que muda na virada
        do mês.
   ===================================================================== */


-- 1) SUPORTE — quantidade por categoria (as duas colunas devem ser iguais)
SELECT
    NVL(A.CATEGORIA, NVL(N.CATEGORIA, '(vazio)')) AS CATEGORIA,
    NVL(A.QTD, 0) AS QTD_VIEW_ATUAL,
    NVL(N.QTD, 0) AS QTD_VIEW_NOVA
FROM (
    SELECT NVL(CATEGORIA, '(vazio)') AS CATEGORIA, COUNT(*) AS QTD
    FROM POWERBI_SUPORTE_B2C_NEXUS
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
    GROUP BY NVL(CATEGORIA, '(vazio)')
) A
FULL OUTER JOIN (
    SELECT NVL(CATEGORIA, '(vazio)') AS CATEGORIA, COUNT(*) AS QTD
    FROM VW_NEXUS_SUPORTE_B2C
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
    GROUP BY NVL(CATEGORIA, '(vazio)')
) N ON N.CATEGORIA = A.CATEGORIA
ORDER BY 2 DESC;


-- 2) DEPENDÊNCIA — quantidade por categoria (as duas colunas devem ser iguais)
SELECT
    NVL(A.CATEGORIA, NVL(N.CATEGORIA, '(vazio)')) AS CATEGORIA,
    NVL(A.QTD, 0) AS QTD_VIEW_ATUAL,
    NVL(N.QTD, 0) AS QTD_VIEW_NOVA
FROM (
    SELECT NVL(CATEGORIA, '(vazio)') AS CATEGORIA, COUNT(*) AS QTD
    FROM POWERBI_DEPENDENCIA_NEXUS
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
    GROUP BY NVL(CATEGORIA, '(vazio)')
) A
FULL OUTER JOIN (
    SELECT NVL(CATEGORIA, '(vazio)') AS CATEGORIA, COUNT(*) AS QTD
    FROM VW_NEXUS_DEPENDENCIA_CAMPO
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
    GROUP BY NVL(CATEGORIA, '(vazio)')
) N ON N.CATEGORIA = A.CATEGORIA
ORDER BY 2 DESC;


-- 3) SUPORTE — linha a linha, todas as colunas. Esperado: 0 e 0
SELECT 'só na view atual' AS LADO, COUNT(*) AS LINHAS FROM (
    SELECT * FROM POWERBI_SUPORTE_B2C_NEXUS
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
    MINUS
    SELECT * FROM VW_NEXUS_SUPORTE_B2C
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
)
UNION ALL
SELECT 'só na view nova', COUNT(*) FROM (
    SELECT * FROM VW_NEXUS_SUPORTE_B2C
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
    MINUS
    SELECT * FROM POWERBI_SUPORTE_B2C_NEXUS
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
);


-- 4) DEPENDÊNCIA — linha a linha, todas as colunas. Esperado: 0 e 0
SELECT 'só na view atual' AS LADO, COUNT(*) AS LINHAS FROM (
    SELECT * FROM POWERBI_DEPENDENCIA_NEXUS
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
    MINUS
    SELECT * FROM VW_NEXUS_DEPENDENCIA_CAMPO
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
)
UNION ALL
SELECT 'só na view nova', COUNT(*) FROM (
    SELECT * FROM VW_NEXUS_DEPENDENCIA_CAMPO
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
    MINUS
    SELECT * FROM POWERBI_DEPENDENCIA_NEXUS
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
);


-- 5) Se a consulta 3 ou 4 não der zero: as primeiras linhas diferentes.
--    (troque as duas views para investigar a Dependência)
SELECT * FROM (
    SELECT * FROM POWERBI_SUPORTE_B2C_NEXUS
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
    MINUS
    SELECT * FROM VW_NEXUS_SUPORTE_B2C
    WHERE DATA_INICIO >= TRUNC(ADD_MONTHS(SYSDATE, -5), 'MM') AND DATA_INICIO < TRUNC(SYSDATE)
)
WHERE ROWNUM <= 20;


-- 6) Atualização automática: data da última atualização e execuções do job
SELECT MVIEW_NAME, LAST_REFRESH_DATE, STALENESS
FROM USER_MVIEWS
WHERE MVIEW_NAME = 'MV_NEXUS_SUPORTE_CENTRAL';

SELECT JOB_NAME, STATUS, ACTUAL_START_DATE, RUN_DURATION, ADDITIONAL_INFO
FROM USER_SCHEDULER_JOB_RUN_DETAILS
WHERE JOB_NAME = 'JOB_REFRESH_NEXUS_CENTRAL'
ORDER BY ACTUAL_START_DATE DESC
FETCH FIRST 10 ROWS ONLY;
